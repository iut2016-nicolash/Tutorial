<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <title>Blog NHERBEZ</title>
        <meta name="description" content="Petit blog pour m'initier à PHP">
        <meta name="author" content="Votre Nom">

        <!-- Le HTML5 shim, for IE6-8 support of HTML elements -->
        <!--[if lt IE 9]>
          <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->

        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/style1.css">
    </head>

    <body>
    <!-- <body style="background:url('img/fond1.jpg') no-repeat;"> -->

        <div class="container">

            <div class="content">

                <div class="page-header well">
                    <h1>Nicolas HERBEZ<br><small>LP ASR, iut 2016-2017, création d'un blog</small></h1>
                </div>

                <div class="row">