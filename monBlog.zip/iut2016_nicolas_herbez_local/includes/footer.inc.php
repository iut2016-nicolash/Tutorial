</div> <!-- ferme class="span8" -->
</div> <!-- ferme class="row" -->
</div> <!-- ferme class="content" -->

<footer>
    <br/>
    <p>COPYRIGHT&copy;Nicolas HERBEZ, ULCO 2016-2017, tous droits réservés!</p>

</footer>

</div> <!-- ferme class="container" -->

</body>
</html>