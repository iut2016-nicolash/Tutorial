<?php
/* Smarty version 3.1.30, created on 2016-12-17 09:50:04
  from "C:\wamp\www\iut2016_nicolas_herbez\templates\commentaires_ajout.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5854fc3c0bff97_94623071',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd059c8dfa8fb8b60bd87b0ec7dde86085c2ce6e7' => 
    array (
      0 => 'C:\\wamp\\www\\iut2016_nicolas_herbez\\templates\\commentaires_ajout.tpl',
      1 => 1481874859,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5854fc3c0bff97_94623071 (Smarty_Internal_Template $_smarty_tpl) {
?>
<form action="index.php" method="post" enctype="multipart/form-data" name="form_commentaire_ajout">

    <div class="form_commentaire_ajout">
    <div>
        <label for="texte">Nouveau commentaire</label>
        <div class="input"><textarea name="commentaire" id="commentaire" cols="30" rows="1" placeholder="Ecrivez votre commentaire ici" required=""></textarea></div>
    </div>

    <div>
        <input type="submit" name="Ajouter" value="Ajouter" class="btn btn-medium btn-primary">
    </div>

    <input type="hidden" name="id" value=<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
>
</div>
</form><?php }
}
