<?php
/* Smarty version 3.1.30, created on 2016-12-17 11:58:08
  from "C:\wamp\www\iut2016_nicolas_herbez\templates\connexion.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58551a4017b747_50414812',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b5b3abae21319699d0e5fc7188360cff896c882a' => 
    array (
      0 => 'C:\\wamp\\www\\iut2016_nicolas_herbez\\templates\\connexion.tpl',
      1 => 1481909389,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58551a4017b747_50414812 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="span12">

    <form action="nouveau_compte.php" method="post" id="nouveau_compte_bouton">

        <input type="submit" value="Nouveau compte" name="boutonNouveau_compte" class="btn btn-medium btn-primary"/>

    </form>

    <form action="connexion.php" method="post" id="connexion">

        <!-- l'étiquette login -->
        <label for="email">Email : </label>

        <!-- le champ , type text, "required" rend le champ obligatoire -->
        <input type="text" name="email" placeholder="Rentrer votre email" size="40" maxlength="50" id="email" required/>
        <br>
        <br>

        <!-- l'étiquette mdp -->
        <label for="mdp">Mot de passe : </label>

        <!-- le champ, type password cache le mdp -->
        <input type="password" name="mdp" placeholder="Rentrer votre mdp" size="40" maxlength="50" id="mdp" required/>
        <br>
        <br>

        <div id="echec_connexion"><?php echo $_smarty_tpl->tpl_vars['echec_connexion']->value;?>
</div>
        <input type="submit" value="Connexion" name="boutonValiderConnexion" class="btn btn-medium btn-primary"/>

    </form>

</div>
<?php }
}
