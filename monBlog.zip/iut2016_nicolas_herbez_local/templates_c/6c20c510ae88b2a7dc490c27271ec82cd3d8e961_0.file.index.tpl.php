<?php
/* Smarty version 3.1.30, created on 2016-12-17 09:23:04
  from "C:\wamp\www\iut2016_nicolas_herbez\templates\index.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5854f5e8881bc7_04191984',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6c20c510ae88b2a7dc490c27271ec82cd3d8e961' => 
    array (
      0 => 'C:\\wamp\\www\\iut2016_nicolas_herbez\\templates\\index.tpl',
      1 => 1481960066,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5854f5e8881bc7_04191984 (Smarty_Internal_Template $_smarty_tpl) {
?>
<h2><?php echo $_smarty_tpl->tpl_vars['titre']->value;?>
</h2>
<div id="cadre_article">
    <div id="signature">
        <?php echo $_smarty_tpl->tpl_vars['prenom']->value;?>
 <?php echo $_smarty_tpl->tpl_vars['nom']->value;?>

    </div>
    <img src="img/<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
.jpg" width="600px" alt="photo"/>
    <p id="texte"><?php echo $_smarty_tpl->tpl_vars['texte']->value;?>
</p>

    <div>

        <p id="article_date"><em><u>Publié le : <?php echo $_smarty_tpl->tpl_vars['date']->value;?>
</u></em></p>

        <form action="index.php?modifier=<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
" method="post" enctype="multipart/form-data" id="bouton_article" name="form_article">
            <div class="bouton_article">
                <input type="submit" name="modifier<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
" value="Modifier" class="btn btn-small btn-primary">
            </div>
        </form>

        <form action="index.php?supprimer=<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
" method="post" enctype="multipart/form-data" id="bouton_article" name="form_article">
            <div class="bouton_article">
                <input type="submit" name="supprimer<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
" value="Supprimer" class="btn btn-small btn-primary">
            </div>
        </form>

        <form action="index.php?commentaire=<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
" method="post" enctype="multipart/form-data" id="bouton_article" name="form_article">
            <div class="bouton_article">
                <input type="submit" name="commentaire<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
" value="Commentaires" class="btn btn-small btn-primary">
            </div>
        </form>

        <div class="clear"></div>
    </div>
</div>
<?php }
}
